# Making diagnostics tests into a package
