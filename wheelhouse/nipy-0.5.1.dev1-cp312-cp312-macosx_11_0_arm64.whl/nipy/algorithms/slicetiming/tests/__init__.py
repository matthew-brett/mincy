# Init for slicetiming tests
