# Init for slicetiming subpackage
""" Slicetiming subpackage

The standard nipy method of slice timing is implemented in
:mod:`nipy.algorithms.registration.groupwise_registration`.

This subpackage is a placeholder for other slice timing methods, and for utility
functions for slice timing
"""
