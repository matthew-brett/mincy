# Init for benchmarks for algorithms
