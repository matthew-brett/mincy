""" Utilities for core subpackage """
