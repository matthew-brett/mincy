""" Logic for command line scripts.
"""
