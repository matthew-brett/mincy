#init for nipy/tests
